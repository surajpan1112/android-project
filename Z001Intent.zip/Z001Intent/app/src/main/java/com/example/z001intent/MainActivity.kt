package com.example.z001intent

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loaddata()
        val vbutton=findViewById<Button>(R.id.button)as Button

        vbutton.setOnClickListener()
        {
            savedata()
            callActivity()
        }
    }
    // Shared preference
    private fun loaddata(){
        val vtextview=findViewById<TextView>(R.id.textView4)as TextView

        val vsp=getSharedPreferences("SharedPrefs", Context.MODE_PRIVATE)
        val vsavedstring=vsp.getString("STRING_KEY",null)
        if(vsavedstring==null || vsavedstring=="A")
            vtextview.text="Welcome"
        else
            vtextview.text=vsavedstring+" recently used this app"
    }
    // Shared preference
    private fun savedata(){

        val vedittext=findViewById<EditText>(R.id.edit_text)as EditText
        val vmessage=vedittext.text.toString()
        val vtextview=findViewById<TextView>(R.id.textView4).apply {
            text=vmessage
        }

        val vsp=getSharedPreferences("SharedPrefs", Context.MODE_PRIVATE)
        val veditor=vsp.edit()
        veditor.apply{
            putString("STRING_KEY",vmessage)
        }.apply()
    }
    // Intent
    private fun callActivity(){
        val vedittext=findViewById<EditText>(R.id.edit_text)as EditText
        val vmessage=vedittext.text.toString()

        val vintent=Intent(this,MainActivity2::class.java).also{
            it.putExtra("xyz",vmessage)
            startActivity(it)
        }
    }
}


